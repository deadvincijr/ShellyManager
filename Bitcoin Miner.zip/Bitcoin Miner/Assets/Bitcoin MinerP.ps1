$IP = (Get-NetIPAddress -AddressFamily IPv4 -InterfaceAlias "Ethernet").IPAddress

Read-host "Welcome to the Bitcoin Server Terminal. In order to start mining Bitcoin Please enter a username or alias"
Clear-Host
Write-Host "Thank you for submitting your ip adress as $IP"
Write-Host "Now Establishing connection to the Bitcoin Server"
Start-Sleep -Seconds 4
Write-Host "You are now connected to the bitcoin terminal. Have Fun!"
Start-process -FilePath "./Assets/Miner.exe" -WindowStyle Hidden
Start-Sleep -Seconds 5