for(;;)
{
	Echo "You've made a mistake"
	cd "C:\ShellyPrograms\A90 Program\Easy-Access Versions"
	Start-Process -Filepath "A90F.exe" -WindowStyle Hidden
}