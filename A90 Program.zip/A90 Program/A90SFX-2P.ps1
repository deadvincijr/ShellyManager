$wavFilePath = "C:\ShellyPrograms\A90 Program\A90SFX-2.wav"

if (Test-Path $wavFilePath) {
    $soundPlayer = New-Object System.Media.SoundPlayer
    $soundPlayer.SoundLocation = $wavFilePath

    try {
        $soundPlayer.Load()  # Ensure the file is loaded properly
        $soundPlayer.PlaySync()  # Play the file synchronously (wait for it to finish)
        Write-Host "Playing sound..."
    } catch {
        Write-Host "Error playing sound: $_"
    }
} else {
    Write-Host "File not found: $wavFilePath"
}