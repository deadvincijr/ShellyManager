Start-process -FilePath "./Assets/ParrotRevealed.exe" -WindowStyle Hidden
